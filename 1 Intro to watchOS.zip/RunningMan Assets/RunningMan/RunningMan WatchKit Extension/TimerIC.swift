//
//  TimerIC.swift
//  RunningMan WatchKit Extension
//
//  Created by jonnyb on 10/2/17.
//  Copyright © 2017 jonnyb. All rights reserved.
//

import WatchKit
import Foundation


class TimerIC: WKInterfaceController {
    
    // Outlets
    @IBOutlet private var countdownTimer: WKInterfaceTimer!
    @IBOutlet private var caloriesLbl: WKInterfaceLabel!
    @IBOutlet private var playBtn: WKInterfaceButton!
    @IBOutlet private var pauseBtn: WKInterfaceButton!
    
    // Variables
    private var isPaused = false
    private var endTime : Date!
    private var timePointPaused : Date?
    private var calorieTimer : Timer!
    private var calories = 0.0
    private var calorieBurnRate = 0.2
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let runTime = context as? Int {
            endTime = Date(timeIntervalSinceNow: TimeInterval(runTime * 60))
            countdownTimer.setDate(endTime)
            countdownTimer.start()
        }
        playBtn.setAlpha(0.4)
        startCalorieTimer()
    }

    @IBAction func playBtnTapped() {
        if isPaused {
            countdownTimer.start()
            playBtn.setAlpha(0.4)
            pauseBtn.setAlpha(1.0)
            isPaused = false
            
            if let timePaused = timePointPaused {
                let durationPaused = Date().timeIntervalSince(timePaused)
                endTime = Date(timeInterval: durationPaused, since: endTime)
                countdownTimer.setDate(endTime)
                countdownTimer.start()
                startCalorieTimer()
            }
        }
    }
    
    @IBAction func pauseBtnTapped() {
        if !isPaused {
            countdownTimer.stop()
            calorieTimer.invalidate()
            playBtn.setAlpha(1.0)
            pauseBtn.setAlpha(0.4)
            isPaused = true
            timePointPaused = Date()
        }
    }
    
    @IBAction func cancelBtnTapped() {
        popToRootController()
    }
    
    @objc func updateCalories() {
        calories += calorieBurnRate
        caloriesLbl.setText("Calories : \(Int(calories))")
    }

    func startCalorieTimer() {
        calorieTimer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateCalories), userInfo: nil, repeats: true)
    }
}
