//
//  InterfaceController.swift
//  RunningMan WatchKit Extension
//
//  Created by jonnyb on 10/2/17.
//  Copyright © 2017 jonnyb. All rights reserved.
//

import WatchKit
import Foundation


class RunSelectIC: WKInterfaceController {

    // Outlets
    @IBOutlet private var startButton: WKInterfaceButton!
    @IBOutlet var runPicker: WKInterfacePicker!
    
    
    // Variables
    private var selectedRunTime = 5
    private var runItems: [WKPickerItem] = []
    private var runTimes = [Int]()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        for i in 0...16 {
            let runTime = i * 5
            runTimes.append(runTime)
            
            let run = WKPickerItem()
            run.contentImage = WKImage(imageName: "run\(i + 1)")
            runItems.append(run)
        }
        
        runPicker.setItems(runItems)
        runPicker.setSelectedItemIndex(1)
    }

    override func contextForSegue(withIdentifier segueIdentifier: String) -> Any? {
        if segueIdentifier == "toTimer" {
            return selectedRunTime
        }
        return nil
    }
    
    @IBAction func runPicked(_ value: Int) {
        selectedRunTime = runTimes[value]
        startButton.setTitle("Start \(selectedRunTime) min run")
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
